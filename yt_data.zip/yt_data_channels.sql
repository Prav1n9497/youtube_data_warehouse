-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: yt_data
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(255) NOT NULL,
  `channel_id` varchar(255) NOT NULL,
  `Subscription_Count` int DEFAULT NULL,
  `Channel_Views` bigint DEFAULT NULL,
  `Channel_Description` text,
  `Playlist_Id` varchar(255) DEFAULT NULL,
  `Playlist_Name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` VALUES (27,'World Affairs by Unacademy','UCCJsQKOKArvDksacfT2ryQw',3520000,2156539401,'2.1 Billion+ Views with 130M+ watch hours in just 2 years!\n\nWelcome to the World Affairs YouTube channel from Unacademy.\nThis platform is the one-stop solution that gives you the best insight on how to prepare various topics on Current Affairs for competitive exams.\n\nEvery day we provide insightful knowledge on International Affairs to keep our learners transcending traditional boundaries of education through critical thinking to prepare for Civil Service Examinations.\n\nUnacademy platform has the best educators from all over the country, who take live classes daily.\nSubscribe to our channel to push your limits!\n\n','UUCJsQKOKArvDksacfT2ryQw',''),(28,'Abhijit Chavda','UC2bBsPXFWZWiBmkRiNlz8vg',762000,95737455,'The Abhijit Chavda channel is an expansive library of content that offers insights into geopolitics, contemporary world affairs and history from an Indian perspective.\n\nAbhijit Chavda is the host of the Abhijit Chavda Podcast and #AskAbhijit show which are the home to discussions with subject matter experts from around the world on topics that covers geopolitics, world and Indian history, world affairs, culture and science.\n\nAbhijit Chavda\'s unique research-backed worldview has made him one of the strongest voices in the Indian Digital Space, and he has represented India at international forums, including the G20 summit.\n\nDon\'t forget to SUBSCRIBE and HIT the notification bell to stay up-to-date with the latest videos!\n','UU2bBsPXFWZWiBmkRiNlz8vg','');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-18 17:34:53
